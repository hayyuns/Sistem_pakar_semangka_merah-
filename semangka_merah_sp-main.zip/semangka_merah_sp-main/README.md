# semangka_merah_sp
Aplikasi Sistem Pakar Diagnosa Semangka Merah
