package com.android.sistempakar.semangka_merah.Konsultasi;

public class gejalapenyakit {
    String ID;
    String diagnosa;
    String kembali;
    String tidak;
    String ya;

    public String getDiagnosa() {
        return this.diagnosa;
    }

    public void setDiagnosa(String diagnosa) {
        this.diagnosa = diagnosa;
    }

    public String getYa() {
        return this.ya;
    }

    public void setYa(String ya) {
        this.ya = ya;
    }

    public String getTidak() {
        return this.tidak;
    }

    public void setTidak(String tidak) {
        this.tidak = tidak;
    }

    public String getKembali() {
        return this.kembali;
    }

    public void setKembali(String kembali) {
        this.kembali = kembali;
    }

    public String getID() {
        return this.ID;
    }

    public void setID(String iD) {
        this.ID = iD;
    }
}
